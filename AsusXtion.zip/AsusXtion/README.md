# Asus XTION test
Test script for Asus XTION + OpenNI2

Display RGB+Depth

OpenNi2: https://github.com/occipital/openni2
