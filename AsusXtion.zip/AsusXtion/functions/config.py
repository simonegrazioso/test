ALCOR = False  # if we use ALCOR Asus Xtion, False otherwise
